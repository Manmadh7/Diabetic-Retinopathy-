from django.shortcuts import render
from django.core.files.storage import FileSystemStorage
from django.conf import settings
import os
import tensorflow as tf
import numpy as np
from PIL import Image
from .models import PatientHistory

# Load model
MODEL_PATH = os.path.join(settings.BASE_DIR, "dr_app", "models", "binary_dr_cnn.keras")
model = tf.keras.models.load_model(MODEL_PATH)

def index(request):
    context = {}
    if request.method == "POST" and request.FILES.get("file"):
        name = request.POST.get("name")
        age = request.POST.get("age")
        uploaded_file = request.FILES["file"]

        fs = FileSystemStorage()
        file_path = fs.save(uploaded_file.name, uploaded_file)
        file_url = fs.url(file_path)

        # preprocess
        img = Image.open(fs.path(file_path)).resize((224, 224))
        img_array = np.array(img) / 255.0
        img_array = np.expand_dims(img_array, axis=0)

        prediction = model.predict(img_array)[0][0]
        result = "Diabetic Retinopathy Detected" if prediction > 0.5 else "No DR Detected"

        # Save to DB
        history = PatientHistory.objects.create(
            name=name,
            age=age,
            uploaded_image=file_path,
            prediction_result=result
        )

        context = {"file_url": file_url, "result": result, "patient": history}

    return render(request, "index.html", context)

def history(request):
    records = PatientHistory.objects.all().order_by("-uploaded_at")
    return render(request, "history.html", {"records": records})
