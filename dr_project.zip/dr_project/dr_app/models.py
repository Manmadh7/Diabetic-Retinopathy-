from django.db import models

class PatientHistory(models.Model):
    name = models.CharField(max_length=100)
    age = models.IntegerField()
    uploaded_image = models.ImageField(upload_to="uploads/")
    prediction_result = models.CharField(max_length=50)
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.name} ({self.age}) - {self.prediction_result}"
